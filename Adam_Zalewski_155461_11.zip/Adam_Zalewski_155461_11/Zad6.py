import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import numpy as np

def randrange(n, vmin, vmax):
    return (vmax - vmin)*np.random.rand(n) + vmin


fig = plt.figure()
ax = fig.add_subplot( 121 , projection = '3d' )
n = 20
for c, m, zlow, zhigh in [( 'r' , 'o' , 0 , 10 )]:
    xs = randrange(n, 23 , 32 )
    ys = randrange(n, -50 , 50 )
    zs = randrange(n, zlow, zhigh)
    ax.scatter(xs, ys, zs, c =c, marker =m)
ax.set_xlabel( 'X Label' )
ax.set_ylabel( 'Y Label' )
ax.set_zlabel( 'Z Label' )

ax2 = fig.add_subplot( 122 , projection = '3d' )
z=0
x=range(-3,3)
y=np.power(x,3)
ax2.plot(x, y, z)
ax2.set_xlabel( 'X Label' )
ax2.set_ylabel( 'Y Label' )
ax2.set_zlabel( 'Z Label' )
plt.show()