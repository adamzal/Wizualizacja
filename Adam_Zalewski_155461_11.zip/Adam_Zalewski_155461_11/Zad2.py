import matplotlib.pyplot as plt
import numpy as np
import random

def randrange(n, vmin, vmax):
    return (vmax - vmin)*np.random.rand(n) + vmin
def losujmarker(marker):
    x=random.randint(0,len(marker)-1)
    wynik= marker[x]
    marker.remove(marker[x])
    return wynik
def losujkolor(kolor):
    x=random.randint(0,len(kolor)-1)
    wynik= kolor[x]
    kolor.remove(kolor[x])
    return wynik
def losujint():
    return random.randint(-50,50)

fig = plt.figure()
ax = fig.add_subplot( 111 , projection = '3d' )
n = 20
marker = ["D", "o", "v", "^", "h", ">", "1", "s", "8"]
kolor = ["r", "b", "g", "y", "m", "c", "tab:orange", "grey", "chocolate"]
for x in range(5):
    for c, m, zlow, zhigh in [( losujkolor(kolor) , losujmarker(marker) ,losujint() , losujint() )]:
        xs = randrange(n, 23 , 32 )
        ys = randrange(n, 0 , 100 )
        zs = randrange(n, zlow, zhigh)
        ax.scatter(xs, ys, zs, c =c, marker =m)
ax.set_xlabel( 'X Label' )
ax.set_ylabel( 'Y Label' )
ax.set_zlabel( 'Z Label' )
plt.show()