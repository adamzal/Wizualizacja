import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import xlrd
import openpyxl


df = pd.read_csv('zamowienia.data', delimiter=';')
grupa=df.groupby(['Sprzedawca']).size()
wykres = grupa.plot.bar()
wykres.set_ylabel('Liczba zamówień')
wykres.set_xlabel('Sprzedający')
wykres.legend()
plt.title('Liczba zamówień u sprzedającego')
plt.show()