import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import xlrd
import openpyxl

xlsx = pd.ExcelFile('imiona.xlsx')
df = pd.read_excel(xlsx)
data = {'Rok': [df['Rok'][x] for x in range(len(df))],'Imie':[df['Imie'][x] for x in range(len(df))],
'Liczba': [df['Liczba'][x] for x in range(len(df))],'Plec':[df['Plec'][x] for x in range(len(df))]}
df = pd.DataFrame(data, columns=['Rok','Imie','Liczba','Plec'])
grupa = df.groupby(['Plec']).agg({'Liczba':['sum']})
wykres = grupa.plot.bar()
wykres.set_ylabel('Liczba urodzonych dzieci')
wykres.set_xlabel('Płeć')
wykres.legend()
plt.title('Liczba urodzonych chłopców i dziewczynek')
plt.show()