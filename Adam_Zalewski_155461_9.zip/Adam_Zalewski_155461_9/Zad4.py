import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import xlrd
import openpyxl


df = pd.read_csv('iris.data',header=None)
data={'w':[df[0][x] for x in range(len(df))],'x':[df[1][x] for x in range(len(df))],'y':[df[2][x] for x in range(len(df))],
      'z':[df[3][x] for x in range(len(df))],'Nazwa':[df[4][x] for x in range(len(df))]}
df=pd.DataFrame(data,columns=['x','y','Nazwa'])
for x in range(len(df)):
    a=df['Nazwa'][0]
    if(df['Nazwa'][x]==a):
        i=x;
x1=[]
y1=[]
for x in range(i):
    x1+=[df['x'][x]]
    y1+=[df['y'][x]]
a=df['Nazwa'][i+1]
for x in range(len(df)):
    if(df['Nazwa'][x]==a):
        j=x;
x2=[]
y2=[]
for x in range(i,j):
    x2+=[df['x'][x]]
    y2+=[df['y'][x]]
a=df['Nazwa'][j+1]
for x in range(len(df)):
    if(df['Nazwa'][x]==a):
        k=x;
x3=[]
y3=[]
for x in range(j,k):
    x3+=[df['x'][x]]
    y3+=[df['y'][x]]
#Pewnie da się to zrobić w krótszy sposób, ale nie mam pomysłu jak
fig = plt.figure()
ax = fig.add_subplot(111)
ax.scatter(x1,y1,
 color='green',
 marker='.',
 label=df['Nazwa'][i])
ax.scatter(x2,y2,
 color='red',
 marker='.',
 label=df['Nazwa'][j])
ax.scatter(x3,y3,
 color='black',
 marker='.',
 label=df['Nazwa'][k])
plt.legend()
plt.show()

