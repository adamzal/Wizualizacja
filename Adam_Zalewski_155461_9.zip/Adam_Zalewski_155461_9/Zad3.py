import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import xlrd
import openpyxl

xlsx = pd.ExcelFile('imiona.xlsx')
df = pd.read_excel(xlsx)
for x in range(len(df)):
    if(df['Rok'][x]==2015):
        i=x;
        break;
data = {'Rok': [df['Rok'][x] for x in range(i,len(df))],'Imie':[df['Imie'][x] for x in range(i,len(df))],
'Liczba': [df['Liczba'][x] for x in range(i,len(df))],'Plec':[df['Plec'][x] for x in range(i,len(df))]}
df = pd.DataFrame(data, columns=['Rok','Imie','Liczba','Plec'])
grupa = df.groupby(['Plec']).agg({'Liczba':['sum']})
wykres = grupa.plot.pie(subplots=True, autopct='%.2f %%', fontsize=20, figsize=(6, 6))
plt.title('Liczba urodzonych mężczyzn i kobiet')
plt.show()