import pandas as pd
import matplotlib.pyplot as plt

xlsx = pd.ExcelFile('imiona.xlsx')
df = pd.read_excel(xlsx)
data = {'Rok': [df['Rok'][x] for x in range(len(df))],'Imie':[df['Imie'][x] for x in range(len(df))],
'Liczba': [df['Liczba'][x] for x in range(len(df))],'Plec':[df['Plec'][x] for x in range(len(df))]}
df = pd.DataFrame(data, columns=['Rok','Imie','Liczba','Plec'])
plt.subplot(131)
etykiety = ['K', 'M']
m=0
k=0
for x in range(len(df)):
    if(df['Plec'][x]=='M'):
        m+=df['Liczba'][x]
    else:
        k+=df['Liczba'][x]
wartości=[k,m]
plt.bar(etykiety,wartości)
plt.ylabel('Liczba urodzonych dzieci')
plt.xlabel('Płeć')

plt.subplot(132)
lata=[]
for x in range(len(df)):
    if(not(df['Rok'][x]in lata)):
        lata+=[df['Rok'][x]]
m=[]
k=[]
for x in range(len(lata)):
    ml = 0
    kl = 0
    for y in range(len(df)):
        if(df['Rok'][y]==lata[x]and df['Plec'][y]=='M'):
            ml += df['Liczba'][y]
        if (df['Rok'][y] == lata[x] and df['Plec'][y] == 'K'):
            kl += df['Liczba'][y]
    m += [ml]
    k += [kl]
plt.plot(lata,m,label='mężczyźni')
plt.plot(lata,k,label='kobiety')
plt.ylabel('Liczba urodzonych dzieci')
plt.xlabel('Lata')

plt.subplot(133)
suma=[]
for x in range(len(m)):
    suma+=[m[x]+k[x]]
plt.bar(lata,suma)
plt.ylabel('Liczba urodzonych dzieci')
plt.xlabel('Lata')
plt.show()
