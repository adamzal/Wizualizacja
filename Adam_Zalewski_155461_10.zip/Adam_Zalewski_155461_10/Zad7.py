import pandas as pd
import matplotlib.pyplot as plt

xlsx = pd.ExcelFile('imiona.xlsx')
df = pd.read_excel(xlsx)
data = {'Rok': [df['Rok'][x] for x in range(len(df))],'Imie':[df['Imie'][x] for x in range(len(df))],
'Liczba': [df['Liczba'][x] for x in range(len(df))],'Plec':[df['Plec'][x] for x in range(len(df))]}
df = pd.DataFrame(data, columns=['Rok','Imie','Liczba','Plec'])

lata=[]
for x in range(len(df)):
    if(not(df['Rok'][x]in lata)):
        lata+=[df['Rok'][x]]
m=[]
k=[]
for x in range(len(lata)):
    ml = 0
    kl = 0
    for y in range(len(df)):
        if(df['Rok'][y]==lata[x]and df['Plec'][y]=='M'):
            ml += df['Liczba'][y]
        if (df['Rok'][y] == lata[x] and df['Plec'][y] == 'K'):
            kl += df['Liczba'][y]
    m += [ml]
    k += [kl]
plt.bar(lata,m,label='mężczyźni')
plt.bar(lata,k,label='kobiety',bottom=m)
plt.show()