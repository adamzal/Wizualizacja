import numpy as np
import matplotlib.pyplot as plt

x = np.arange(0, 30, 0.1)
s = np.sin(x)
t=np.cos(x)
plt.plot(x, s, label='sin(x)')
plt.plot(x,t,label='cos(x)')
plt.xlabel('x')
plt.ylabel('f(x)')
plt.title("Wykres sin(x) i cos(x)")
plt.legend()
plt.show()