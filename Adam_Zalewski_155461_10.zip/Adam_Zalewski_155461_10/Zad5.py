import numpy as np
import matplotlib.pyplot as plt

data={
'x': [4.3,7.9,5.84,0.83,0.7826],
'y':[2.0,4.4,3.05,0.43,-0.4194],
'c':np.random.randint(0, 5, 5),
'd': np.random.randn(5)}
for x in range(5):
    data['d'][x] = np.abs(data['x'][x]-data['y'][x])
plt.scatter('x', 'y', c='c', s='d', data=data)
plt.xlabel('wartość x')
plt.ylabel('wartość y')
plt.show()
