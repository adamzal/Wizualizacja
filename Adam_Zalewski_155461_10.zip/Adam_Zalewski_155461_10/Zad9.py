import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

df = pd.read_csv('zamowienia.data', delimiter=';')
sprzedawcy=[]
for x in range(len(df)):
    if(not(df['Sprzedawca'][x]in sprzedawcy)):
        sprzedawcy+=[df['Sprzedawca'][x]]
zam=[]
for x in range(len(sprzedawcy)):
    i=0
    for y in range(len(df)):
        if(sprzedawcy[x]==df['Sprzedawca'][y]):
            i+=1
    zam+=[i]

def prepare_label(pct, br):
    absolute = int(np.ceil(pct / 100. * np.sum(br)))
    return "{:.1f}% \n({}/{})".format(pct, absolute, sum(zam))


wedges, texts, autotexts = plt.pie(zam, labels=sprzedawcy,
                                   autopct=lambda pct: prepare_label(pct, zam), textprops=dict(color="black"))
plt.setp(autotexts, size=14, weight="bold")
plt.title("Udział sprzedawcy w ogólnej sumie zamówień")
plt.legend(title='Sprzedawcy')
plt.show()