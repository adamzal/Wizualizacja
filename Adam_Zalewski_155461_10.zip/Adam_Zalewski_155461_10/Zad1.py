import numpy as np
import matplotlib.pyplot as plt

fig, ax = plt.subplots(figsize=(8, 5))
x = np.linspace(1, 20)
plt.plot(x, 1/x, label='homograficzna')
plt.axis([0, 20, 0, 1])
plt.xlabel('x')
plt.ylabel('f(x)')
plt.title("Wykres funkcji homograficznej")
plt.legend()

#Zad 10
ax.annotate('koniec osi Y',
            xy=(0, 1), xycoords='data',
            xytext=(-30, 30), textcoords='offset points',
            arrowprops=dict(arrowstyle="->"))
ax.annotate('początek układu współrzędnych',
            xy=(0, 0), xycoords='data',
            xytext=(0, 20), textcoords='offset points',
            arrowprops=dict(arrowstyle="->"))
ax.annotate('P(2,0.5)',
            xy=(2, 0.5), xycoords='data',
            xytext=(0, 30), textcoords='offset points',
            arrowprops=dict(arrowstyle="->"))
ax.annotate('legenda',
            xy=(14.9, 0.9), xycoords='data',
            xytext=(-50, -30), textcoords='offset points',
            arrowprops=dict(arrowstyle="->"))

plt.show()