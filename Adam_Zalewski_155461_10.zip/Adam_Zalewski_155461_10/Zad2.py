import numpy as np
import matplotlib.pyplot as plt

fig, ax = plt.subplots(figsize=(8, 5))
x = np.arange(1, 20, 1)
plt.plot(x, 1/x,'g^:', label='homograficzna')
plt.axis([0, 20, 0, 1])
plt.xlabel('x')
plt.ylabel('f(x)')
plt.title("Wykres funkcji homograficznej")
plt.legend()

#Zad 10
ax.annotate('tytuł wykresu',
            xy=(9.75, 1), xycoords='data',
            xytext=(-50, -30), textcoords='offset points',
            arrowprops=dict(arrowstyle="->"))
ax.annotate('P(7,0.1428)',
            xy=(7, 0.1428), xycoords='data',
            xytext=(-20, 30), textcoords='offset points',
            arrowprops=dict(arrowstyle="->"))
ax.annotate('informacja o rodzaju funkcji',
            xy=(17.45, 0.91), xycoords='data',
            xytext=(-100, -30), textcoords='offset points',
            arrowprops=dict(arrowstyle="->"))
plt.show()