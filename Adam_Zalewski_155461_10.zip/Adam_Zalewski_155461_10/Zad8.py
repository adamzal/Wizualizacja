import matplotlib.pyplot as plt
import random

def rzucaj(x):
    suma=[]
    for a in range(x):
        kostka1=random.randint(1,6)
        kostka2=random.randint(1,6)
        suma+=[kostka1+kostka2]
    return suma

x=rzucaj(6)
plt.hist(x,bins=6,facecolor='r',alpha=0.75, density=True)
plt.xlabel('Wartości sum')
plt.ylabel('Prawdopodobieństwo ')
plt.title('Histogram rzutu 2 kostkami')
plt.grid(True)
plt.show()
